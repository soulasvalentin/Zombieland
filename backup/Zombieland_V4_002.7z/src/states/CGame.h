#ifndef GAME_H_INCLUDED
#define GAME_H_INCLUDED

//-------------------------------------------
//  HEADERS NECESARIOS PARA LA CLASE "GAME"
//-------------------------------------------

#include "CMenu.h"
#include "game/CEnemy.h"
#include "game/CInventory.h"
#include "game/CPlayer.h"
#include "game/CMap.h"
#include "game/CBullets.h"

/**
    ************************
    * CLASS CGAME
    ************************

    Detalles:
        - Administra todo el juego
        - Posee los objetos necesarios definidos
          dentro de la parte privada
*/

class CGame{

    private:

        int selec;
        ALLEGRO_BITMAP *barra;
        bool ready_to_shoot;
        bool reloading;
        bool reloaded;
        double reload_time_start;
        double last_time_shot;
        int live_vEnemies;
        int live_vBullets;

        CBullets vBullets[NUM_BULLETS];
        CEnemy   vEnemies[NUM_ENEMIES];

        // Creaci�n de objetos
        CInventory Inventory;
        CMap actual_map;
        CPlayer player;

    public:

        void start_game();          // Inicializar
        void update_game();         // Actualizar
        void render_game();         // Dibujar por pantalla
        void destroy_game();        // Destruir bitmaps
        void dev_mode();

        int getScore(){return player.getScore();}

        /// Devuelve el inventario completo
        CInventory& getInventory(){return Inventory;}

        CGame();
};

CGame::CGame(){

    selec = 0;
    barra = al_load_bitmap("resources/misc/barra_transparente.png");
    GameState.changeSaved(false);
    ready_to_shoot = true;
    reloading = false;
    reloaded = true;
    reload_time_start = 0;
    last_time_shot = 0;

    Inventory.init();
}


///*********************************************
///*               START GAME
///*********************************************

void CGame::start_game(){

    //-------------------------------
    //  SE INICIALIZA EL JUEGO
    //  Solo se ejecuta con la opci�n "Nueva Partida"
    //------------------------------------------------

    player.init(3466,346,"resources/sprites/players/aliado2.png",55,64);
    actual_map.init("resources/maps/mapa_test.jpg");
    Inventory.init();

    GameState.changeRunning(true);

    for (int i=0; i<NUM_BULLETS; i++)
        vBullets[i].init(Inventory.getActual_weap());

    for(int i=0; i<NUM_ENEMIES; i++){
        if(i<15) vEnemies[i].init(EASY);
        else if(i<35) vEnemies[i].init(NORMAL);
        else if(i<40) vEnemies[i].init(HARD);
    }

    //-------------------------------
    //  SE CAMBIA AL ESTADO PLAYING
    //-------------------------------

    GameState.changeState(PLAYING);
}


///*********************************************
///*              UPDATE GAME
///*********************************************

void CGame::update_game(){

    //-------------------------------
    //  IMPUT DE DISPLAY
    //-------------------------------

    if(ev.type == ALLEGRO_EVENT_DISPLAY_CLOSE)
        GameState.changeState(EXIT);

    //-------------------------------
    //  IMPUT DE TECLADO
    //-------------------------------

    else if(ev.type == ALLEGRO_EVENT_KEY_DOWN){

        if(ev.keyboard.keycode == ALLEGRO_KEY_ESCAPE){
            GameState.changeState(INGAMEMENU);
            for(int i=0; i<7; i++)
                keys[i] = false;
        }

        switch(ev.keyboard.keycode){

            // W,A,S,D
            case ALLEGRO_KEY_A:     keys[LEFT]  = true; break;
            case ALLEGRO_KEY_D:     keys[RIGHT] = true; break;
            case ALLEGRO_KEY_W:     keys[UP]    = true; break;
            case ALLEGRO_KEY_S:     keys[DOWN]  = true; break;

            // OTRAS TECLAS
            case ALLEGRO_KEY_1:     player.teleport();      break;
            case ALLEGRO_KEY_2:     Inventory.add_credits(100); break;
            case ALLEGRO_KEY_3:     player.hit_recived(20); break;
            case ALLEGRO_KEY_TAB:   keys[TAB] = true;       break;
            case ALLEGRO_KEY_F1:    if(GameState.getDebug_info()) GameState.changeDebug_info(false);
                                    else GameState.changeDebug_info(true);
                                break;
            case ALLEGRO_KEY_F2:    if(GameState.getGame_info()) GameState.changeGame_info(false);
                                    else GameState.changeGame_info(true);
                                break;
            case ALLEGRO_KEY_SPACE: keys[SPACE] = true;     break;
            case ALLEGRO_KEY_F9:    dev_mode();             break;
        }

    }

    //-------------------------------
    //  PONE LAS TECLAS EN "FALSE"
    //-------------------------------

    if(ev.type == ALLEGRO_EVENT_KEY_UP){

        if     (ev.keyboard.keycode == ALLEGRO_KEY_A)       keys[LEFT]  = false;
        else if(ev.keyboard.keycode == ALLEGRO_KEY_D)       keys[RIGHT] = false;
        else if(ev.keyboard.keycode == ALLEGRO_KEY_W)       keys[UP]    = false;
        else if(ev.keyboard.keycode == ALLEGRO_KEY_S)       keys[DOWN]  = false;
        else if(ev.keyboard.keycode == ALLEGRO_KEY_SPACE)   keys[SPACE] = false;
        else if(ev.keyboard.keycode == ALLEGRO_KEY_TAB){

            // SELECCIONA EL ARMA CON MOUSEOVER
            keys[TAB] = false;
            Inventory.select_weapon(player.getX(),player.getY());
        }
    }

    //-------------------------------------------
    //  ACTUALIZA EL JUEGO 60 VECES POR SEGUNDO
    //-------------------------------------------

    if(GameState.getRedraw()){

        player.update();
        player.update_ant();

        if(!reloading and !reloaded and Inventory.getAmmunition() > 0){

            if(Inventory.getAmmunition()%Inventory.getWeapon_mag_size() == 0){

                reload_time_start = al_get_time();
                reloading = true;
            }
        }

        if(!ready_to_shoot){

            if(al_get_time()-last_time_shot > Inventory.getWeapon_fire_rate())
                ready_to_shoot = true;

        }

        if(reloading){

            if(al_get_time() > reload_time_start + Inventory.getWeapon_reload_time()){

                reloading = false;
                reloaded = true;
            }
        }

        if(keys[SPACE] and ready_to_shoot and !reloading){

            reloaded = false;
            ready_to_shoot = false;
            last_time_shot = al_get_time();

            // Evalua si hay municion
            if(Inventory.getAmmunition() > 0){
                for (int i=0; i<NUM_BULLETS; i++){

                    // Dispara la primera bala que no este viva
                    if(!vBullets[i].getLive()){
                        vBullets[i].fire(player.getX(),player.getY());

                        // Resta municion
                        Inventory.ammunition_edit(Inventory.getActual_weap(),-1);

                        // Reproduce sonido
                        al_play_sample(audios[Inventory.getActual_weap()],.5,0,1,ALLEGRO_PLAYMODE_ONCE, NULL);
                        break;
                    }
                }
            }
        }

        live_vBullets = 0;
        for (int i=0; i<NUM_BULLETS; i++){

            if(vBullets[i].getLive()){
                live_vBullets++;
                vBullets[i].update();
                if(vBullets[i].isOutRange())
                    vBullets[i].destroy();
            }else
                vBullets[i].init(Inventory.getActual_weap());
        }

        live_vEnemies = 0;
        for(int i=0; i<NUM_ENEMIES; i++){

            if(vEnemies[i].getLive()){

                live_vEnemies++;

                // Actualizar la pos del enemigo
                vEnemies[i].update(player.getX()+player.getW()/2,player.getY()+player.getH()/2);

                // Colision entre enemigos
                for(int j=0; j<NUM_ENEMIES; j++){
                    if(vEnemies[j].getLive() and i != j){
                        if(collision::circle_circle(vEnemies[i].getX(),vEnemies[i].getY(),vEnemies[i].getRadio(),
                                                    vEnemies[j].getX(),vEnemies[j].getY(),vEnemies[j].getRadio())){
                            vEnemies[i].setAnt();
                        }
                    }
                }

                // Colision con el jugador
                if(collision::circle_circle(vEnemies[i].getX(),vEnemies[i].getY(),vEnemies[i].getRadio(),
                                            player.getX()+player.getW()/2,player.getY()+player.getH()/2,30)){
                    vEnemies[i].setAnt();
                    if(rand()%100==0)player.hit_recived(vEnemies[i].getDamage());
                }

                // Colision con las balas
                for(int j=0; j<NUM_BULLETS; j++)
                    if(vBullets[j].getLive())
                        if(collision::circle_circle(vEnemies[i].getX(),vEnemies[i].getY(),vEnemies[i].getRadio(),
                                                    vBullets[j].getX(),vBullets[j].getY(),2)){

                            // Enemigo recibe da�o. Si muere, el usuario adquiere creditos y puntos
                            if(vEnemies[i].recive_hit(vBullets[j].getDamage())){
                                Inventory.add_credits(25);
                                player.addScore();

                            }

                            // Matar la bala
                            vBullets[j].setLive(false);
                        }

                // Actualizar pos ant
                vEnemies[i].update_ant();
            }
        }

        if(player.getStamina() == 0){
            GameState.changeState(GAMEOVER);
            GameState.changeRunning(false);
        }

        // MUEVE LA CAMARA CON LA POS DEL JUGADOR
        cameraUpdate(player.getX(),player.getY(),
                     player.getW(),player.getH());
        al_identity_transform(&camera);
        al_translate_transform(&camera,-camx,-camy);
        al_use_transform(&camera);
    }
}


///*********************************************
///*               RENDER GAME
///*********************************************

void CGame::render_game(){

    //-------------------------------
    //  DIBUJA EL MAPA
    //-------------------------------

    actual_map.draw(-player.getX(),-player.getY());
    player.render();

    //-------------------------------
    //  DIBUJA EL INVENTARIO
    //-------------------------------

    if(keys[TAB])
        Inventory.show_weapons_mouseover(player.getX(),player.getY());

    //-------------------------------
    //  DIBUJA LAS BALAS
    //-------------------------------

    for(int i=0; i<NUM_BULLETS; i++)
        vBullets[i].render(Inventory.getActual_weap());

    //-------------------------------
    //  DIBUJA LOS ENEMIGOS
    //-------------------------------

    for(int i=0; i<NUM_ENEMIES; i++){
        vEnemies[i].render();
        vEnemies[i].draw_stamina();
        if(GameState.getDebug_info()){
            vEnemies[i].show_debug();
        }
        if(GameState.getGame_info()){
            vEnemies[i].show_aggro_distance();
        }
    }

    //--------------------------------------------
    //  DIBUJA INFORMACION DEL JUEGO POR PANTALLA
    //--------------------------------------------

    Inventory.show_ammunition_by_actual_weapon(reloading);
    Inventory.show_actualweapon();
    Inventory.show_info();
    player.draw_stamina_bar();
    player.draw_score();

    // Dibuja arco con weapon reload time
    if(reloading)
        al_draw_arc(player.getX()+(player.getW()/2),player.getY()+(player.getH()/2),40,0,
                    (al_get_time()-last_time_shot)*(6.3/Inventory.getWeapon_reload_time()),al_map_rgb(200,200,20),5);

    //-------------------------------
    //  DIBUJA INFORMACION (DEBUG)
    //-------------------------------

    if(GameState.getDebug_info()){


        al_draw_textf(keepcalm12,al_map_rgb(250,250,250),camx+5,camy+110,0,"camera x: %i",(int)camx);
        al_draw_textf(keepcalm12,al_map_rgb(250,250,250),camx+5,camy+125,0,"camera y: %i",(int)camy);
        al_draw_textf(keepcalm12,al_map_rgb(250,250,250),camx+5,camy+170,0,"live vEnemies: %i",live_vEnemies);
        al_draw_textf(keepcalm12,al_map_rgb(250,250,250),camx+5,camy+185,0,"live vBullets: %i",live_vBullets);
        player.show_debug();
        al_draw_textf(keepcalm12,al_map_rgb(250,250,250),camx+5,camy+215,0,"reloading: %i",reloading);
        al_draw_textf(keepcalm12,al_map_rgb(250,250,250),camx+5,camy+230,0,"ammunition: %i",Inventory.getAmmunition());
        Inventory.show_debug_info();
    }
    if(GameState.getGame_info()){

        // Dibuja arco con weapon fire rate
        if(!ready_to_shoot)
            al_draw_arc(player.getX()+(player.getW()/2),player.getY()+(player.getH()/2),50,0,
                        (al_get_time()-last_time_shot)*(6.3/Inventory.getWeapon_fire_rate()),al_map_rgb(255,255,255),1);

        // Dibuja arco con weapon reload time
        if(reloading)
            al_draw_arc(player.getX()+(player.getW()/2),player.getY()+(player.getH()/2),20,0,
                        (al_get_time()-last_time_shot)*(6.3/Inventory.getWeapon_reload_time()),al_map_rgb(255,255,255),40);
    }
}

void CGame::dev_mode(){

    Inventory.aquire_weapon(SHOTGUN);
    Inventory.aquire_weapon(UZI);
    Inventory.aquire_weapon(ASSAULT);
    Inventory.add_credits(50000);
    Inventory.ammunition_edit(SHOTGUN,500);
    Inventory.ammunition_edit(UZI,500);
    Inventory.ammunition_edit(ASSAULT,500);
    player.addMax_stamina(200);
    player.setStamina(player.getMax_stamina());

    al_show_native_message_box(display,"Informacion","Dev","Modo DEV activado","Button",0);
}

bool save_game(CGame aux){

    FILE *p = fopen("files/savegames.dat","ab");
    if(p == NULL){
        al_show_native_message_box(display,"Informacion","Error de archivo","No se pudo abrir el archivo.","Button",0);
        return false;
    }
    if(fwrite(&aux,sizeof(CGame),1,p)){
        al_show_native_message_box(display,"Informacion","Archivo guardado","Se ha guardado la partida exitosamente.","Button",0);
        fclose(p);
        return true;
    }
    al_show_native_message_box(display,"Informacion","Error al guardar","No se pudo guardar la partida.","Button",0);
    fclose(p);
    return false;
}

///*********************************************
///*             DESTROY GAME
///*********************************************

void CGame::destroy_game(){

    //--------------------------------------
    //  DESTRUYE LOS ELEMENTOS DEL JUEGO
    //--------------------------------------

    player.destroy();
    actual_map.destroy_bitmap();
    Inventory.destroy_bitmaps();
}

#endif // GAME_H_INCLUDED
