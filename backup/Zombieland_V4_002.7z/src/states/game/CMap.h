#ifndef MAP_H_INCLUDED
#define MAP_H_INCLUDED

class CMap{

private:
    int w,h;
    ALLEGRO_BITMAP *bmp = NULL;

public:

    int getW(){return w;}
    int getH(){return h;}

    void init(char*);
    void draw(int,int);
    void destroy_bitmap(){al_destroy_bitmap(bmp);}
};

void CMap::init(char *BMP){

    //-------------------------------
    //  INICIALIZA EL MAPA
    //-------------------------------

    bmp = al_load_bitmap(BMP);
    if(bmp == NULL) cout << " MAPA NULL" << endl;
    else{
        ANCHO_MAPA = w = al_get_bitmap_width(bmp);
        ALTO_MAPA  = h = al_get_bitmap_height(bmp);
    }
}

void CMap::draw(int xp, int yp){

    //-------------------------------
    //  DIBUJA EL MAPA
    //-------------------------------

    if(bmp != NULL)
        al_draw_bitmap(bmp,0,0,0);
}

#endif // MAP_H_INCLUDED
