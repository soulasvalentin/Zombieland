#ifndef ENEMY_H_INCLUDED
#define ENEMY_H_INCLUDED
#include "CGameObject.h"

/// CLASS ENEMY

class CEnemy:public CPhysicalObject{

private:

    int radio;

    int w,h;
    int direc;
    int frame;

    int stamina;
    int stamina_max;
    float speed;
    int aggro_distance;
    int damage;

    ENEMY_STATE state;
    ENEMY_AI ai;

public:

    void init(ENEMY_AI _AI);

    void update(int x_target, int y_target);
    void die();
    bool recive_hit(int hit); // Devuelve 1 si muere

    float distance_target(int x1, int y1, int x2, int y2);
    float angle_target(int x1, int y1, int x2, int y2);

    void render();
    void draw_stamina();
    void show_aggro_distance();
    void show_initial_distance();
    void show_debug();

    void destroy(){}

    int getRadio(){return radio;}
    int getDamage(){return damage;}
};

void CEnemy::init(ENEMY_AI _AI){


    //-------------------------------
    //  INICIALIZA EL ENEMIGO
    //-------------------------------


    xa = x = rand() % (ANCHO_MAPA);
    if(x < ANCHO_MAPA-1200)
        ya = y = rand() % ALTO_MAPA;
    else
        ya = y = 850 + rand() % ALTO_MAPA;

    live = true;
    w = 55;
    h = 64;
    radio = 20;
    direc = rand() % 7;
    frame = 0;
    state = INMOVIL;
    ai = _AI;

    //-------------------------------
    //  INICIALIZA LA DIFICULTAD DEL ENEMIGO
    //-------------------------------

    switch(_AI){

    case EASY:
        stamina_max = stamina = 100;
        speed = 0.4;
        aggro_distance = 300;
        damage = 5;
        break;

    case NORMAL:
        stamina_max = stamina = 200;
        speed = 0.6;
        aggro_distance = 300;
        damage = 15;
        break;

    case HARD:
        stamina_max = stamina = 280;
        speed = 1.2;
        aggro_distance = 500;
        damage = 25;
        break;
    }
}

void CEnemy::update(int x_target, int y_target){

    //-------------------------------
    //  ADMINISTRA EL ESTADO DEL ENEMIGO
    //  MUEVE AL ENEMIGO
    //-------------------------------

    if(state == INMOVIL){

        if(aggro_distance > distance_target(x_target,y_target,x,y))
            state = PERSIGUIENDO;
    }
    else if(state == PERSIGUIENDO){


            float angle = angle_target(x,y,x_target,y_target);
            y += (sin(angle)) * speed;
            x += (cos(angle)) * speed;

            if(aggro_distance < distance_target(x,y,x_target,y_target))
                state = INMOVIL;

    }

}

void CEnemy::die(){

    live = false;
}

bool CEnemy::recive_hit(int hit){

    stamina -= hit;
    if(stamina <= 0){
        die();
        return true;
    }else
        return false;
}

float CEnemy::distance_target(int x1, int y1, int x2, int y2){

    //-------------------------------
    //  CALCULA LA DISTANCIA AL OBJETIVO
    //-------------------------------

    return sqrt(pow((float)x1-x2,2) + pow((float)y1-y2,2));
}
float CEnemy::angle_target(int x1, int y1, int x2, int y2){

    //-------------------------------
    //  CALCULA EL ANGULO CON EL OBJETIVO
    //-------------------------------

    float dX = (x2 - x1);
    float dY = (y2 - y1);

    return atan2(dY,dX);
}

void CEnemy::render(){

    //-------------------------------
    //  DIBUJA EL ENEMIGO DEPENDIENDO SU DIFICULTAD
    //-------------------------------

    if(live){
        switch(ai){

        case EASY:
            al_draw_filled_circle(x,y,radio,al_map_rgb(20,240,20));
            break;
        case NORMAL:
             al_draw_filled_circle(x,y,radio,al_map_rgb(255,158,13));
            break;
        case HARD:
             al_draw_filled_circle(x,y,radio,al_map_rgb(255,20,20));
            break;
        }
        al_draw_circle(x,y,radio,al_map_rgb(20,20,20),2);
    }
}

void CEnemy::draw_stamina(){

    if(live){


        al_draw_filled_rectangle(x-25,y-30,x-25+(stamina*100/stamina_max)/2,y-35,al_map_rgb(34,255,190));
        al_draw_rectangle       (x-25,y-30,x+25,y-35,al_map_rgb(20,20,20),1);

        //al_draw_textf(keepcalm12,al_map_rgb(20,20,20),x,y+radio+10,ALLEGRO_ALIGN_CENTER,"HP: %i",stamina);
    }
}

void CEnemy::show_aggro_distance(){

    //-------------------------------
    //  DIBUJA EL RANGO DE VISI�N MAXIMO
    //-------------------------------
    if(live)
        al_draw_circle(x,y,aggro_distance,al_map_rgb(220,20,20),1);
}


void CEnemy::show_debug(){

    //-------------------------------
    //  MUESTRA LA VELOCIDAD DEL ENEMIGO
    //-------------------------------
    if(live){
        al_draw_textf(keepcalm12,al_map_rgb(250,250,250),x+radio+5,y-radio,0,"speed: %.1f",speed);
        al_draw_textf(keepcalm12,al_map_rgb(250,250,250),x+radio+5,y-radio+15,0,ENEMY_STATE_t[state]);
    }
}

#endif // ENEMY_H_INCLUDED



















