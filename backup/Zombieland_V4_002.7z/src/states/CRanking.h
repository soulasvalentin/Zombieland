#ifndef CRANKING_H_INCLUDED
#define CRANKING_H_INCLUDED
#include "CMenu.h"

/**
    ************************
    * CLASS CRANKING
    ************************


*/

class CRanking:public CMenu{


    public:

        void render_ranking();
        void open_ranking();
        CRanking():CMenu("VOLVER","CERRAR"){}
};


void CRanking::render_ranking(){

    //-------------------------------
    //  LEER IMPUTS
    //-------------------------------

    switch(read_imput()){

        case BACK:  GameState.changeState(MAINMENU);   break;
        case SELECT:

            //---------------------------------------
            //  CAMBIAR DE ESTADO SEGUN 'SELECTION'
            //---------------------------------------

            switch(selection){
                case 0: GameState.changeState(MAINMENU);   break;
                case 1: GameState.changeState(EXIT);       break;
            }
            break;
    }
}

void CRanking::open_ranking(){

    //-------------------------------
    //  MOSTRAR LA SELECCI�N
    //-------------------------------

    render_selection();

    //-------------------------------
    //  MOSTRAR LAS OPCIONES
    //-------------------------------

    render_options();
}

#endif // CRANKING_H_INCLUDED
