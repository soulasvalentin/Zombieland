#ifndef CSTORE_H_INCLUDED
#define CSTORE_H_INCLUDED
#include "CMenu.h"

/**
    ************************
    * CLASS CSTORE
    ************************

    Detalles:
        -
*/

class CStore{

private:

    // Control de sub-estados para la tienda
    enum STORE_STATE{ARMAS,MEJORAS,MUNICIONES,COMIDAS,BEBIDAS,VOLVER};
    STORE_STATE state;

    // Precios
    int cost[5][3];

    // Controla la seleccion de opcion
    int selec;

    ALLEGRO_BITMAP *weapon_img = NULL;
    ALLEGRO_BITMAP *buy_bmp = NULL;

public:

    void open_Store(CInventory&);
    void render_Store(CInventory&);
    void show_state();
    void destroy_bitmaps();

    // Renders por sub-estado
    void render_armas(CInventory&);
    void render_mejoras();
    void render_municiones();
    void render_comidas();
    void render_bebidas();

    // Cambia de sub-estado (sub menu)
    void changeState(STORE_STATE new_state){state = new_state;}

    CStore();
};

//-------------------------------
//  CONSTRUCTOR
//-------------------------------

CStore::CStore(){

    //----------------------------------------
    //  INICIALIZAR VECTOR DE COSTOS EN CERO
    //----------------------------------------

    for(int i=0; i<3; i++)
        for(int j=0; j<5; j++)
            cost[i][j] = 0;

    //----------------------------------------
    //  ASIGNAR VALORES AL VECTOR DE COSTOS
    //----------------------------------------

    cost[ARMAS][SHOTGUN] = 250;
    cost[ARMAS][UZI]     = 570;
    cost[ARMAS][ASSAULT] = 1200;

    selec = 0;
    state = ARMAS;
    weapon_img =     al_load_bitmap("resources/sprites/weapons/weapons.png");
    buy_bmp =        al_load_bitmap("resources/menus/store/botones.png");
}

///*********************************************
///*               OPEN STORE
///*********************************************

void CStore::open_Store(CInventory &inventory_aux){

    //-------------------------------
    //  IMPUT DE DISPLAY
    //-------------------------------

    if(ev.type == ALLEGRO_EVENT_DISPLAY_CLOSE)
            GameState.changeState(EXIT);

    //-------------------------------
    //  IMPUT DE TECLADO
    //-------------------------------

    else if(ev.type == ALLEGRO_EVENT_KEY_DOWN){

        switch(ev.keyboard.keycode){
        case ALLEGRO_KEY_DOWN:
            selec++;
            if(selec>5) selec = 0;
            break;
        case ALLEGRO_KEY_UP:
            selec--;
            if(selec<0) selec = 5;
            break;
        case ALLEGRO_KEY_PAD_ENTER:
        case ALLEGRO_KEY_ENTER:
            if(selec == 5){
                GameState.changeState(INGAMEMENU);
                selec = 0;
            }
            break;
        case ALLEGRO_KEY_ESCAPE:
            GameState.changeState(INGAMEMENU);
            selec = 0;
            break;

        }
    }

    //-------------------------------
    //  COMPRAR ARMAS CON MOUSE
    //-------------------------------

    else if(ev.type == ALLEGRO_EVENT_MOUSE_BUTTON_DOWN){

    // COMPRAR ESCOPETA
        if(collision::boundingBox_pixel(ANCHO*.34+ANCHO*0.65*0.25+camx,ALTO*.78+camy,
            ANCHO*0.34+ANCHO*0.65*0.50+camx,ALTO*.85+camy,x_mouse,y_mouse))

            if(inventory_aux.getCredits() >= cost[ARMAS][SHOTGUN] and !inventory_aux.getWeapon(SHOTGUN)){
                inventory_aux.aquire_weapon(SHOTGUN);
                inventory_aux.add_credits(-cost[ARMAS][SHOTGUN]);
            } else if(inventory_aux.getWeapon(SHOTGUN))
                al_show_native_message_box(display,"Informacion","Error de tienda","No puede obtener el arma. Usted ya posee este arma.","Button",0);
            else
                al_show_native_message_box(display,"Informacion","Error de tienda","No puede obtener el arma. Fondos insuficientes.","Button",0);

    // COMPRAR UZI
        if(collision::boundingBox_pixel(ANCHO*.34+ANCHO*0.65*0.50+camx,ALTO*.78+camy,
            ANCHO*0.34+ANCHO*0.65*0.75+camx,ALTO*.85+camy,x_mouse,y_mouse))

            if(inventory_aux.getCredits() >= cost[ARMAS][UZI] and !inventory_aux.getWeapon(UZI)){
                inventory_aux.aquire_weapon(UZI);
                inventory_aux.add_credits(-cost[ARMAS][UZI]);
            } else if(inventory_aux.getWeapon(UZI))
                al_show_native_message_box(display,"Informacion","Error de tienda","No puede obtener el arma. Usted ya posee este arma.","Button",0);
            else
                al_show_native_message_box(display,"Informacion","Error de tienda","No puede obtener el arma. Fondos insuficientes.","Button",0);

    // COMPRAR ASSAULT
        if(collision::boundingBox_pixel(ANCHO*.34+ANCHO*0.65*0.75+camx,ALTO*.78+camy,
            ANCHO+camx,ALTO*.85+camy,x_mouse,y_mouse))

            if(inventory_aux.getCredits() >= cost[ARMAS][ASSAULT] and !inventory_aux.getWeapon(ASSAULT)){
                inventory_aux.aquire_weapon(ASSAULT);
                inventory_aux.add_credits(-cost[ARMAS][ASSAULT]);
            } else if(inventory_aux.getWeapon(ASSAULT))
                al_show_native_message_box(display,"Informacion","Error de tienda","No puede obtener el arma. Usted ya posee este arma.","Button",0);
            else
                al_show_native_message_box(display,"Informacion","Error de tienda","No puede obtener el arma. Fondos insuficientes.","Button",0);

    }

    //-----------------------------------------------------------
    //  Cambia el estado dependiendo de la seleccion del usuario
    //-----------------------------------------------------------

    switch(selec){
        case 0: changeState(ARMAS);         break;
        case 1: changeState(MEJORAS);       break;
        case 2: changeState(MUNICIONES);    break;
        case 3: changeState(COMIDAS);       break;
        case 4: changeState(BEBIDAS);       break;
        case 5: changeState(VOLVER);        break;
    }



}

///*********************************************
///*              RENDER STORE
///*********************************************

void CStore::render_Store(CInventory &inventory_aux){

    //-------------------------------
    //  MOSTRAR TITULO
    //-------------------------------

    al_draw_text(dayslater_big,al_map_rgb(255,255,20),ANCHO/2+camx,(ALTO*0.15)-90+camy,ALLEGRO_ALIGN_CENTER,"TIENDA");

    //-------------------------------
    //  DIBUJAR ESTRUCTURA
    //-------------------------------

    al_draw_line(camx,(ALTO*0.15)+camy,camx+ANCHO,(ALTO*0.15)+camy,al_map_rgb(180,180,180),2); // -----
    al_draw_line((ANCHO*0.34)+camx,(ALTO*0.15)+camy,(ANCHO*0.34)+camx,(ALTO*0.85)+camy,al_map_rgb(180,180,180),2);// |
    al_draw_line(camx,(ALTO*0.85)+camy,camx+ANCHO,(ALTO*0.85)+camy,al_map_rgb(180,180,180),2); // _____

    //-------------------------------
    //  MOSTRAR CREDITOS DEL JUGADOR
    //-------------------------------

    al_draw_textf(keepcalm_med,al_map_rgb(82,204,0),ANCHO*0.34+camx,ALTO*0.86+camy,ALLEGRO_ALIGN_RIGHT,"CREDITOS: %i",inventory_aux.getCredits());

    //-------------------------------
    //  RENDERIZA SUB-ESTADO
    //-------------------------------

    switch(selec){
        case ARMAS: render_armas(inventory_aux); break;

    }

    //---------------------------------
    //  MOSTRAR LA OPCION SELECCIONADA
    //---------------------------------

    if(selec !=5)
        al_draw_filled_rectangle(5+camx,(ALTO*0.15)+(48*selec)+camy+10,(ANCHO*0.34)+camx-10,(ALTO*0.15)+(48*selec)+42+camy+15,al_map_rgb(180,180,180));
    else
        al_draw_filled_rectangle(5+camx,(ALTO*0.85)-58+camy,(ANCHO*0.34)+camx-10,(ALTO*0.85)-10+camy,al_map_rgb(180,180,180));

    //-------------------------------
    //  MOSTRAR LAS OPCIONES
    //-------------------------------

    if(selec == 0)
        al_draw_text(keepcalm24,al_map_rgb(20,20,20),(ANCHO*0.34)+camx-10,(ALTO*0.15)+camy+10,ALLEGRO_ALIGN_RIGHT,"ARMAS");
    else al_draw_text(keepcalm24,al_map_rgb(180,180,180),(ANCHO*0.34)+camx-10,(ALTO*0.15)+camy+10,ALLEGRO_ALIGN_RIGHT,"ARMAS");

    if(selec == 1)
        al_draw_text(keepcalm24,al_map_rgb(20,20,20),(ANCHO*0.34)+camx-10,(ALTO*0.15)+camy+58,ALLEGRO_ALIGN_RIGHT,"MEJORAS");
    else al_draw_text(keepcalm24,al_map_rgb(180,180,180),(ANCHO*0.34)+camx-10,(ALTO*0.15)+camy+58,ALLEGRO_ALIGN_RIGHT,"MEJORAS");

    if(selec == 2)
        al_draw_text(keepcalm24,al_map_rgb(20,20,20),(ANCHO*0.34)+camx-10,(ALTO*0.15)+camy+106,ALLEGRO_ALIGN_RIGHT,"MUNICIONES");
    else al_draw_text(keepcalm24,al_map_rgb(180,180,180),(ANCHO*0.34)+camx-10,(ALTO*0.15)+camy+106,ALLEGRO_ALIGN_RIGHT,"MUNICIONES");

    if(selec == 3)
        al_draw_text(keepcalm24,al_map_rgb(20,20,20),(ANCHO*0.34)+camx-10,(ALTO*0.15)+camy+154,ALLEGRO_ALIGN_RIGHT,"COMIDAS");
    else al_draw_text(keepcalm24,al_map_rgb(180,180,180),(ANCHO*0.34)+camx-10,(ALTO*0.15)+camy+154,ALLEGRO_ALIGN_RIGHT,"COMIDAS");

    if(selec == 4)
        al_draw_text(keepcalm24,al_map_rgb(20,20,20),(ANCHO*0.34)+camx-10,(ALTO*0.15)+camy+202,ALLEGRO_ALIGN_RIGHT,"BEBIDAS");
    else al_draw_text(keepcalm24,al_map_rgb(180,180,180),(ANCHO*0.34)+camx-10,(ALTO*0.15)+camy+202,ALLEGRO_ALIGN_RIGHT,"BEBIDAS");

    if(selec == 5)
        al_draw_text(keepcalm24,al_map_rgb(20,20,20),(ANCHO*0.34)+camx-10,(ALTO*0.85)+camy-58,ALLEGRO_ALIGN_RIGHT,"VOLVER");
    else al_draw_text(keepcalm24,al_map_rgb(180,180,180),(ANCHO*0.34)+camx-10,(ALTO*0.85)+camy-58,ALLEGRO_ALIGN_RIGHT,"VOLVER");

    show_state();
    GameState.show_state_debug();
}

///*********************************************
///*          RENDERS POR SUB-ESTADO
///*********************************************

void CStore::render_armas(CInventory &inventory_aux){

    // Estructura
    al_draw_line(ANCHO*0.34+ANCHO*0.65*0.25+camx,ALTO*0.16+camy,ANCHO*0.34+ANCHO*0.65*0.25+camx,ALTO*0.84+camy,al_map_rgb(180,180,180),1);
    al_draw_line(ANCHO*0.34+ANCHO*0.65*0.50+camx,ALTO*0.16+camy,ANCHO*0.34+ANCHO*0.65*0.50+camx,ALTO*0.84+camy,al_map_rgb(180,180,180),1);
    al_draw_line(ANCHO*0.34+ANCHO*0.65*0.75+camx,ALTO*0.16+camy,ANCHO*0.34+ANCHO*0.65*0.75+camx,ALTO*0.84+camy,al_map_rgb(180,180,180),1);

    // Textos
    al_draw_text(keepcalm12,al_map_rgb(180,180,180),ANCHO*0.42+camx,ALTO*0.16+camy,ALLEGRO_ALIGN_CENTER,"PISTOL");
    al_draw_text(keepcalm12,al_map_rgb(180,180,180),ANCHO*0.58+camx,ALTO*0.16+camy,ALLEGRO_ALIGN_CENTER,"SHOTGUN");
    al_draw_text(keepcalm12,al_map_rgb(180,180,180),ANCHO*0.74+camx,ALTO*0.16+camy,ALLEGRO_ALIGN_CENTER,"UZI");
    al_draw_text(keepcalm12,al_map_rgb(180,180,180),ANCHO*0.91+camx,ALTO*0.16+camy,ALLEGRO_ALIGN_CENTER,"ASSAULT");

    // Imagenes
    al_draw_bitmap_region(weapon_img,139*PISTOL, 43*SELECTED,139,43,ANCHO*0.34+(ANCHO*0.65*0.25-139)/2+camx,ALTO*0.20+camy,0);
    al_draw_bitmap_region(weapon_img,139*SHOTGUN,43*SELECTED,139,43,ANCHO*0.34+ANCHO*0.65*0.25+(ANCHO*0.65*0.25-139)/2+camx,ALTO*0.20+camy,0);
    al_draw_bitmap_region(weapon_img,139*UZI,    43*SELECTED,139,43,ANCHO*0.34+ANCHO*0.65*0.50+(ANCHO*0.65*0.25-139)/2+camx,ALTO*0.20+camy,0);
    al_draw_bitmap_region(weapon_img,139*ASSAULT,43*SELECTED,139,43,ANCHO*0.34+ANCHO*0.65*0.75+(ANCHO*0.65*0.25-139)/2+camx,ALTO*0.20+camy,0);

    // Boton de compra o cartel de obtenido
    bool *weapons_aux=inventory_aux.getWeapons();

    al_draw_text(keepcalm_med,al_map_rgb(250,160,0),ANCHO*0.42+camx,ALTO*0.795+camy,ALLEGRO_ALIGN_CENTER,"OBTENIDA");

    if(weapons_aux[SHOTGUN]==1)
        al_draw_text(keepcalm_med,al_map_rgb(250,160,0),ANCHO*0.58+camx,ALTO*0.795+camy,ALLEGRO_ALIGN_CENTER,"OBTENIDA");
    else{
        al_draw_bitmap(buy_bmp,ANCHO*0.34+ANCHO*0.65*0.25+(ANCHO*0.65*0.25-al_get_bitmap_width(buy_bmp))/2+camx,ALTO*0.79+camy,0);
        al_draw_textf(keepcalm_med,al_map_rgb(250,160,0),ANCHO*0.58+camx,ALTO*0.75+camy,ALLEGRO_ALIGN_CENTER,"$%i",cost[ARMAS][SHOTGUN]);
    }
    if(weapons_aux[UZI]==1)
        al_draw_text(keepcalm_med,al_map_rgb(250,160,0),ANCHO*0.74+camx,ALTO*0.795+camy,ALLEGRO_ALIGN_CENTER,"OBTENIDA");
    else{
        al_draw_bitmap(buy_bmp,ANCHO*0.34+ANCHO*0.65*0.50+(ANCHO*0.65*0.25-al_get_bitmap_width(buy_bmp))/2+camx,ALTO*0.79+camy,0);
        al_draw_textf(keepcalm_med,al_map_rgb(250,160,0),ANCHO*0.74+camx,ALTO*0.75+camy,ALLEGRO_ALIGN_CENTER,"$%i",cost[ARMAS][UZI]);
    }
    if(weapons_aux[ASSAULT]==1)
        al_draw_text(keepcalm_med,al_map_rgb(250,160,0),ANCHO*0.91+camx,ALTO*0.795+camy,ALLEGRO_ALIGN_CENTER,"OBTENIDA");
    else{
        al_draw_bitmap(buy_bmp,ANCHO*0.34+ANCHO*0.65*0.75+(ANCHO*0.65*0.25-al_get_bitmap_width(buy_bmp))/2+camx,ALTO*0.79+camy,0);
        al_draw_textf(keepcalm_med,al_map_rgb(250,160,0),ANCHO*0.91+camx,ALTO*0.75+camy,ALLEGRO_ALIGN_CENTER,"$%i",cost[ARMAS][ASSAULT]);
    }
}

void CStore::render_mejoras(){


}

void CStore::render_municiones(){


}

void CStore::render_comidas(){


}

void CStore::render_bebidas(){


}


//-------------------------------
//  MUESTRA EL SUB-ESTADO ACTUAL
//-------------------------------

void CStore::show_state(){

    switch(state){

        case ARMAS:         al_draw_text(keepcalm12,al_map_rgb(180,180,180),5+camx,ALTO-30+camy,0,"SUB STATE: ARMAS"); break;
        case MEJORAS:       al_draw_text(keepcalm12,al_map_rgb(180,180,180),5+camx,ALTO-30+camy,0,"SUB STATE: MEJORAS"); break;
        case MUNICIONES:    al_draw_text(keepcalm12,al_map_rgb(180,180,180),5+camx,ALTO-30+camy,0,"SUB STATE: MUNICIONES"); break;
        case COMIDAS:       al_draw_text(keepcalm12,al_map_rgb(180,180,180),5+camx,ALTO-30+camy,0,"SUB STATE: COMIDAS"); break;
        case BEBIDAS:       al_draw_text(keepcalm12,al_map_rgb(180,180,180),5+camx,ALTO-30+camy,0,"SUB STATE: BEBIDAS"); break;
        case VOLVER:        al_draw_text(keepcalm12,al_map_rgb(180,180,180),5+camx,ALTO-30+camy,0,"SUB STATE: VOLVER"); break;
    }
}

///*********************************************
///*            DESTRUIR BITMAPS
///*********************************************

void CStore::destroy_bitmaps(){

    al_destroy_bitmap(weapon_img);
    al_destroy_bitmap(buy_bmp);
}

#endif // CSTORE_H_INCLUDED
