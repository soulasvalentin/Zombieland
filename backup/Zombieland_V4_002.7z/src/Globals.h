#ifndef GLOBALS_H_INCLUDED
#define GLOBALS_H_INCLUDED

///*********************************************
///*            GLOBALES
///*********************************************

//-------------------------------
//  VARIABLES DE ALLEGRO
//-------------------------------

ALLEGRO_DISPLAY *display = NULL;
ALLEGRO_EVENT_QUEUE *event_queue = NULL;
ALLEGRO_TIMER *timer = NULL;
ALLEGRO_FONT *keepcalm24 = NULL,*farial = NULL,*keepcalm12 = NULL,
             *keepcalm_med = NULL,*dayslater36 = NULL,*dayslater_big = NULL;
ALLEGRO_EVENT ev;
ALLEGRO_BITMAP *menu_select = NULL;
ALLEGRO_TRANSFORM camera;
ALLEGRO_SAMPLE *audios[5]={NULL,NULL,NULL,NULL,NULL};

//-------------------------------
//  ENUMS
//-------------------------------

enum GAME_STATE     {MAINMENU,OPCIONES,INGAMEMENU,STORE,PRE_GAME,START_PLAYING,PLAYING,HELP,
                     GAMEOVER,RANKING,SAVE_GAME,EXIT};
char *GAME_STATE_t[]={"MAINMENU","OPCIONES","INGAMEMENU","STORE","PRE_GAME","START_PLAYING","PLAYING","HELP",
                      "GAMEOVER","RANKING","SAVE_GAME","EXIT"};
enum DIREC          {NOROESTE,NORTE,NORESTE,ESTE,OESTE,SUDOESTE,SUR,SURESTE,QUIETO};
enum WEAP           {PISTOL,SHOTGUN,UZI,ASSAULT};
char *WEAP_t[] =    {"PISTOL","SHOTGUN","UZI","ASSAULT"};
enum WEAP_STATE     {SELECTED,UNSELECTED};
enum ENEMY_STATE    {INMOVIL,PERSIGUIENDO,VOLVIENDO};
char *ENEMY_STATE_t[]={"INMOVIL","PERSIGUIENDO","VOLVIENDO"};
enum ENEMY_AI       {EASY,NORMAL,HARD};
enum MENU_ACTION    {GOUP,GODOWN,BACK,SELECT,QUIT,NONE};
enum KEYS           {UP,DOWN,LEFT,RIGHT,SPACE,ONE,TAB};
bool keys[7] =      {0,0,0,0,0,0,0};
/* Si se modifica la cantidad > cambiar for de CGame */

//-------------------------------
//  VARIABLES DEL PROGRAMA
//-------------------------------

int ANCHO,ALTO;
int ANCHO_MAPA,ALTO_MAPA;
const int NUM_BULLETS = 20;
const int NUM_ENEMIES = 40;
float camx = 0, camy = 0;       // Coordenadas de la c�mara
int x_mouse = 0,y_mouse = 0;    // Coordenadas del mouse


#endif // GLOBALS_H_INCLUDED

















