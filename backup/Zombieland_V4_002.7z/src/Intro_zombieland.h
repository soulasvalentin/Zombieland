#ifndef INTRO_ZOMBIELAND_H_INCLUDED
#define INTRO_ZOMBIELAND_H_INCLUDED

void intro_zombieland(){

    bool done = false;
    ALLEGRO_BITMAP *intro__zombieland = al_load_bitmap("resources/menus/intro_zombieland.jpg");
    int w = al_get_bitmap_width(intro__zombieland);
    int h = al_get_bitmap_height(intro__zombieland);
    int h_new;

    while(!done){

        al_wait_for_event(event_queue, &ev);
        if(ev.type == ALLEGRO_EVENT_KEY_DOWN)
            done = true;

        h_new = (ANCHO*h)/w;

        al_draw_scaled_bitmap(intro__zombieland,0,0,w,h,0,ALTO/2-(h_new/2),ANCHO,h_new,0);

        al_draw_text(keepcalm_med,al_map_rgb(255,255,20),ANCHO/2,ALTO-150,ALLEGRO_ALIGN_CENTER,"PRESIONE UNA TECLA");

        al_flip_display();
        al_clear_to_color(al_map_rgb(20,20,20));

    }
    al_destroy_bitmap(intro__zombieland);
}

#endif // INTRO_ZOMBIELAND_H_INCLUDED
