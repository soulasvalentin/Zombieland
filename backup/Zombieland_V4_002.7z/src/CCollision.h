#ifndef COLITION_H_INCLUDED
#define COLITION_H_INCLUDED

class collision{

public:

    static bool boundingBox_pixel(int x1,int y1,int x2,int y2,int px,int py);
    static bool circle_pixel(int x1,int y1,int r1,int x2,int y2);
    static bool circle_circle(int x1,int y1,int r1,int x2,int y2,int r2);
};


//-------------------------------
//  COLISION RECTANGULO - PIXEL
//-------------------------------

bool collision::boundingBox_pixel(int x1,int y1,int x2,int y2,int px,int py){

    if(px+camx > x1 and px+camx < x2 and py+camy > y1 and py+camy < y2)
        return true;
    else
        return false;
}

//-------------------------------
//  COLISION CIRCULO - CIRCULO
//-------------------------------

bool collision::circle_circle(int x1,int y1,int r1,int x2,int y2,int r2){

    float distance = sqrt(pow((float)x1-x2,2) + pow((float)y1-y2,2));

    if(distance < (r1 + r2))
        return true;
    else
        return false;
}


#endif // COLITION_H_INCLUDED
