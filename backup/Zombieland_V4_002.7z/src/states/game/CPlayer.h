#ifndef PLAYER_H_INCLUDED
#define PLAYER_H_INCLUDED
#include "CGameObject.h"

/**
    *******************
    * CLASS CHARACTER *
    *******************

    - Clase dedicada a los personajes y ejecuciones de sus comportamientos
*/

class CPlayer:public CPhysicalObject{

    private:

        int w,h;
        int direc,frame;
        int vel, stamina, max_stamina;
        int score;
        char name[20];
        ALLEGRO_BITMAP *bmp = NULL;

    public:

        void init(int,int,char *,int,int);
        void update();
        void render();
        void teleport();
        void hit_recived(int ammount);
        void show_debug();
        void draw_stamina_bar();
        void draw_score();
        void destroy() {al_destroy_bitmap(bmp);}

        // Setters && Getters && Addition
        int getW(){return w;}
        int getH(){return h;}
        int getMax_stamina(){return max_stamina;}
        int getScore(){return score;}
        int getStamina(){return stamina;}
        void addMax_stamina(int cant=1){max_stamina += cant; if(max_stamina > 400) max_stamina = 400;}
        void addScore(int cant=1){score += cant;}
        void setStamina(int _stamina){stamina = _stamina; if(stamina > max_stamina) stamina = max_stamina;}

};


void CPlayer::init(int X,int Y,char *BMP,int W,int H){

    //-------------------------------
    //  INICIALIZA EL JUGADOR
    //-------------------------------

    w = W;
    h = H;

    xa = x = X;
    ya = y = Y;

    direc = ESTE;
    frame = 56;

    vel = 1;
    max_stamina = stamina = 200;
    score = 0;
    live = true;

    bmp = al_load_bitmap(BMP);
}


void CPlayer::update(){

    //-------------------------------
    //  ACTUALIZA LA POS DEL JUGADOR
    //-------------------------------

    if(keys[UP] && keys[RIGHT]){
        x += vel;
        y -= vel;
        direc = NORESTE;
        if(frame-- < 0) frame = 72;
    }
    else if(keys[DOWN] && keys[RIGHT]){
        x += vel;
        y += vel;
        direc = SURESTE;
        if(frame-- < 0) frame = 72;
    }
    else if(keys[UP] && keys[LEFT]){
        x -= vel;
        y -= vel;
        direc = NOROESTE;
        if(frame-- < 0) frame = 72;
    }
    else if(keys[DOWN] && keys[LEFT]){
        x -= vel;
        y += vel;
        direc = SUDOESTE;
        if(frame-- < 0) frame = 72;
    }
    else if(keys[UP]){
        y -= vel;
        direc = NORTE;
        if(frame-- < 0) frame = 72;
    }
    else if(keys[DOWN]){
        y += vel;
        direc = SUR;
        if(frame-- < 0) frame = 72;
    }
    else if(keys[LEFT]){
        x -= vel;
        direc = OESTE;
        if(frame-- < 0) frame = 72;
    }
    else if(keys[RIGHT]){
        x += vel;
        direc = ESTE;
        if(frame-- < 0) frame = 72;
    }

    //-------------------------------
    //  COLISION CON LOS BORDES DEL MAPA
    //-------------------------------

    if(x < 0) x = 0;
    if(y < 0) y = 0;
    if(x + 51 > ANCHO_MAPA) x = ANCHO_MAPA - 51;
    if(y + 60 > ALTO_MAPA) y = ALTO_MAPA - 60;
}

void CPlayer::hit_recived(int ammount){

    stamina -= ammount;
    if(stamina < 0)
        stamina = 0;
}

void CPlayer::teleport(){

    //-------------------------------
    //  TELEPORT CON LA TECLA "1"
    //-------------------------------

    x = x_mouse - w/2 + camx;
    y = y_mouse - h/2 + camy;
}

void CPlayer::render(){

    //-------------------------------
    //  DIBUJAR AL JUGADOR
    //-------------------------------

    al_draw_bitmap_region(bmp,(frame/9)*w,direc*h,w,h,x,y,0);
}

void CPlayer::show_debug(){

    //-------------------------------
    //  MUESTRA LA POS DEL JUGADOR
    //-------------------------------

    al_draw_textf(keepcalm12,al_map_rgb(250,250,250),camx+5,camy+140,0,"player x: %i",(int)x);
    al_draw_textf(keepcalm12,al_map_rgb(250,250,250),camx+5,camy+155,0,"player y: %i",(int)y);
    al_draw_textf(keepcalm12,al_map_rgb(250,250,250),camx+5,camy+245,0,"stamina: %i/%i",stamina,max_stamina);

}

void CPlayer::draw_stamina_bar(){

    al_draw_rectangle(camx+4,camy+ALTO-91,camx+6+max_stamina,camy+ALTO-64,al_map_rgb(20,20,20),2);
    al_draw_filled_rectangle(camx+5,camy+ALTO-90,camx+5+max_stamina,camy+ALTO-65,al_map_rgba_f(.1,.1,.1,.1));
    al_draw_filled_rectangle(camx+5,camy+ALTO-90,camx+5+stamina,camy+ALTO-65,al_map_rgb(210,20,20));
    al_draw_text(keepcalm_med,al_map_rgb(255,255,255),camx+7,camy+ALTO-90,0,"STAMINA");
}

void CPlayer::draw_score(){

    al_draw_textf(keepcalm_med,al_map_rgb(50,50,50),ANCHO-5+camx,ALTO-30+camy,ALLEGRO_ALIGN_RIGHT,
                  "SCORE: %i",score);
}

#endif // PLAYER_H_INCLUDED



















